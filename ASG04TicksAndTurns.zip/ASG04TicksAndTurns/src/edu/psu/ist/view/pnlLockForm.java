package edu.psu.ist.view;

import javax.swing.*;

public class pnlLockForm {
    private JPanel jPanel;
    private JButton BtnPull;
    private JButton BtnLeft;
    private JButton BtnRight;
    private JButton BtnReset;
    private JLabel LblLockStatus;
    private JLabel LblCurrentTickValue;

    public JPanel getjPanel() {
        return jPanel;
    }

    public JButton getBtnLeft() {
        return BtnLeft;
    }

    public JButton getBtnPull() {
        return BtnPull;
    }

    public JButton getBtnRight() {
        return BtnRight;
    }

    public JButton getBtnReset() {
        return BtnReset;
    }

    public JLabel getLblLockStatus() {
        return LblLockStatus;
    }

    public JLabel getLblCurrentTickValue() {
        return LblCurrentTickValue;
    }
}
