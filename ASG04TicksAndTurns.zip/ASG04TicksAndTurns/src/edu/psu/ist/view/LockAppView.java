package edu.psu.ist.view;

import javax.swing.*;
import java.awt.*;

public class LockAppView extends JFrame {
    private pnlLockForm form;

    public LockAppView() {
        this.form = new pnlLockForm();
        JPanel content = form.getjPanel();
        this.setContentPane(content);
        this.setPreferredSize(new Dimension(300, 300));
        this.pack();

        this.setTitle("Dial Lock App");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public pnlLockForm form() {
        return form;
    }
}