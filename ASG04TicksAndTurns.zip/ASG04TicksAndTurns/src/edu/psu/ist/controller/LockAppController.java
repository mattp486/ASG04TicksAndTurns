package edu.psu.ist.controller;

import edu.psu.ist.model.IDialLock;
import edu.psu.ist.view.LockAppView;
import java.awt.Color;


import javax.swing.*;

public class LockAppController {
    private final LockAppView view;
    private final IDialLock model;

    public LockAppController(LockAppView view, IDialLock model) {
        this.view = view;
        this.model = model;
        //below are event listeners for the buttons.
        view.form().getBtnRight().addActionListener(e -> {
            model.right(1);
            updateView();
        });

        view.form().getBtnLeft().addActionListener(e -> {
            model.left(1);
            updateView();
        });

        view.form().getBtnReset().addActionListener(e -> {
            model.reset();
            updateView();
        });

        view.form().getBtnPull().addActionListener(e -> {
            boolean success = model.pull();
            String message = success ? "Unlocked!" : "Failed!"; //2 messages based on whether lock is successfully locked or not
            JOptionPane.showMessageDialog(view, message); //dialog and result
            updateView();
        });

        updateView();
    }
    //updates GUI with current state
    private void updateView() {
        view.form().getLblLockStatus().setForeground(Color.RED);
        view.form().getLblCurrentTickValue().setForeground(Color.BLUE);
        view.form().getLblLockStatus().setText("Locked: " + model.toString());
        view.form().getLblCurrentTickValue().setText("LockValue: " + model.currentTick());
    }
}
