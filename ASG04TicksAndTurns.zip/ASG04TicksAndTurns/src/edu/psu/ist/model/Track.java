package edu.psu.ist.model;

import java.util.ArrayList;
import java.util.List;

public class Track implements IDialLock {
    private final int maxTicks;
    private final int s1, s2, s3;
    private int currentTick;
    private final List<Turn> moves;

    // Initializes lock
    public Track(int s1, int s2, int s3, int mTicks) {
        if (s1 < 0 || s2 < 0 || s3 < 0 || mTicks < 0) {
            throw new IllegalArgumentException("Secret digits cannot be negative");
        }
        this.s1 = s1;
        this.s2 = s2;
        this.s3 = s3;
        this.maxTicks = mTicks + 1; // 0 based indexing
        this.currentTick = 0;
        this.moves = new ArrayList<>();
    }

    @Override
    public void reset() {
        currentTick = 0;
        moves.clear();
    }

    @Override
    public void left(int t) {
        // Adjust currentTick when turning left
        if (currentTick - t < 0) {
            currentTick = maxTicks + (currentTick - t);  // wrap around
        } else {
            currentTick -= t;
        }
        moves.add(new Turn(Turn.Direction.L, currentTick)); // Add turn to history
    }

    @Override
    public void right(int t) {
        // Adjust currentTick when turning right
        currentTick = (currentTick + t) % maxTicks;
        moves.add(new Turn(Turn.Direction.R, currentTick)); // Add turn to history
    }

    @Override
    public int currentTick() {
        return currentTick;
    }

    @Override
    public boolean pull() {
        // Validate the lock opening condition
        List<Turn> firstRightTurns = new ArrayList<>();
        List<Turn> secondLeftTurns = new ArrayList<>();
        List<Turn> thirdRightTurns = new ArrayList<>();

        boolean isFirstRight = true, isSecondLeft = false, isThirdRight = false;

        for (Turn move : moves) {
            if (isFirstRight && move.getDirection() == Turn.Direction.R) {
                firstRightTurns.add(move);
            } else if (isFirstRight && move.getDirection() == Turn.Direction.L) {
                isFirstRight = false;
                secondLeftTurns.add(move);
                isSecondLeft = true;
            } else if (isSecondLeft && move.getDirection() == Turn.Direction.L) {
                secondLeftTurns.add(move);
            } else if (isSecondLeft && move.getDirection() == Turn.Direction.R) {
                isSecondLeft = false;
                thirdRightTurns.add(move);
                isThirdRight = true;
            } else if (isThirdRight && move.getDirection() == Turn.Direction.R) {
                thirdRightTurns.add(move);
            }
        }

        // Length of lists must match total moves
        if (firstRightTurns.size() + secondLeftTurns.size() + thirdRightTurns.size() != moves.size()) {
            return false; // Invalid sequence if they don't add up
        }

        // Ensure none of the lists are empty
        if (firstRightTurns.isEmpty() || secondLeftTurns.isEmpty() || thirdRightTurns.isEmpty()) {
            return false;
        }

        // Last number in each list must match secret numbers.
        if (firstRightTurns.get(firstRightTurns.size() - 1).getTick() != s1) {
            return false;
        }
        if (secondLeftTurns.get(secondLeftTurns.size() - 1).getTick() != s2) {
            return false;
        }
        if (thirdRightTurns.get(thirdRightTurns.size() - 1).getTick() != s3) {
            return false;
        }

        return true; // Lock can be opened if above is validated
    }

    @Override
    public String toString() {
        return String.format("Secret digits: [%d, %d, %d]", s1, s2, s3);
    }
}
