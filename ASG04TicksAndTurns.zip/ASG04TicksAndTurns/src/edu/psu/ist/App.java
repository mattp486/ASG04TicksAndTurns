package edu.psu.ist;

import edu.psu.ist.controller.LockAppController;
import edu.psu.ist.model.TrLockImpl;
import edu.psu.ist.view.LockAppView;
import edu.psu.ist.model.IDialLock;

public class App {
    public static void main(String[] args) {
        IDialLock model = new TrLockImpl(8, 3, 4, 10); // Sets vakues for combination
        LockAppView view = new LockAppView(); //lockappview
        LockAppController controller = new LockAppController(view, model); //lockappcontroller

        view.setVisible(true);
    }
}
