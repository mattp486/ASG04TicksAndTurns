package edu.psu.ist.model;

public class TrLockImpl implements IDialLock {
    private final Track track;

    // Initializes secret digits and max ticks
    public TrLockImpl(int s1, int s2, int s3, int mTicks) {
        track = new Track(s1, s2, s3, mTicks);
    }

    @Override
    public void reset() {
        track.reset();
    }

    @Override
    public void left(int t) {
        track.left(t);
    }

    @Override
    public void right(int t) {
        track.right(t);
    }

    @Override
    public int currentTick() {
        return track.currentTick();
    }

    @Override
    public boolean pull() {
        return track.pull();
    }

    @Override
    public String toString() {
        return track.toString();
    }
}
