package edu.psu.ist.model;

public class Turn {
    // Enum for direction of the turn
    public enum Direction {
        L,
        R
    }

    private final Direction direction;  //Turn direction
    private final int tick;  // Tick value

    // Cons to initialize direction and tick
    public Turn(Direction direction, int tick) {
        this.direction = direction;
        this.tick = tick;
    }

    // Getter for direction
    public Direction getDirection() {
        return direction;
    }

    // Getter for tick
    public int getTick() {
        return tick;
    }

    // String representation of the Turn object
    @Override
    public String toString() {
        return direction + "-" + tick;
    }
}
