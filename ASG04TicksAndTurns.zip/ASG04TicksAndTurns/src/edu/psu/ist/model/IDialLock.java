package edu.psu.ist.model;

public interface IDialLock {
    //reset, simple
    void reset();

    //left
    void left(int t);

    //right
    void right(int t);

    //resets value
    int currentTick();

    //try unlock
    boolean pull();
}
